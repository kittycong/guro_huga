# 휴가 일기 🌸

연차 관리 웹 앱 — GitHub Pages로 무료 배포 가능한 정적 웹앱입니다.

**배포 주소 예시:** `https://your-username.github.io/vacation-diary`

---

## 🚀 GitHub Pages 배포 방법

### 1단계 — GitHub 저장소 만들기

1. [github.com](https://github.com) 로그인
2. 우측 상단 **+** → **New repository** 클릭
3. Repository name: `vacation-diary` (원하는 이름)
4. **Public** 선택 (Pages 무료 사용 조건)
5. **Create repository** 클릭

### 2단계 — 파일 업로드

**방법 A — 웹에서 직접 업로드 (쉬운 방법)**
1. 생성된 저장소 페이지에서 **Add file → Upload files** 클릭
2. `index.html` 파일 드래그 앤 드롭
3. **Commit changes** 클릭

**방법 B — Git 명령어**
```bash
git init
git add index.html
git commit -m "초기 배포"
git branch -M main
git remote add origin https://github.com/your-username/vacation-diary.git
git push -u origin main
```

### 3단계 — GitHub Pages 활성화

1. 저장소 상단 **Settings** 탭 클릭
2. 좌측 메뉴 **Pages** 클릭
3. **Source** → **Deploy from a branch** 선택
4. **Branch** → `main` 선택, 폴더는 `/ (root)` 유지
5. **Save** 클릭
6. 1~2분 후 `https://your-username.github.io/vacation-diary` 접속 가능

---

## 💾 데이터 저장 방식

- 브라우저의 **localStorage**에 저장됩니다
- 서버 없이 완전히 정적으로 동작
- 같은 기기·같은 브라우저에서만 데이터 유지
- 브라우저 캐시 삭제 시 데이터도 삭제될 수 있으니 주의

> 팀 공용으로 쓰려면 각자 기기에서 접속해 개인 데이터를 입력하거나,
> 로컬에서 `node app.js`로 서버 버전을 사용하세요.

---

## 기능

| 기능 | 설명 |
|------|------|
| 달력 보기 | 월별 캘린더, 2026년 공휴일/대체공휴일 자동 표시 |
| 연차 기록 | 연차(1일) / 반차(0.5일) / 반반차(0.25일) |
| 연차 설정 | 입사일 기반 자동계산 + 연도별 수동 덮어쓰기 |
| 직원 관리 | 직원 추가·삭제, 개인별 연차 분리 관리 |
| 전체 현황 | 팀 전체 사용률 한눈에 확인 |

---

## 파일 구조

```
vacation-diary/
└── index.html   ← 이 파일 하나로 앱 전체 동작
```
